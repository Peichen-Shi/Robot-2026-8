#!/usr/bin/env bash
set -eo pipefail
cd "${1:-$HOME/lab4_sub4_20261029}"
source env.sh
export LAB4_SIM_HEADLESS=0 LAB4_EXIT_OBSERVATION=8
unset LAB4_KEEP_FINAL_HOLD
mkdir -p results
exec 9>results/.sub7_race.lock
flock -n 9 || { echo 'An existing race is active'; exit 2; }
for specification in '3.9 bias3' '3.9 bias_skew' '3.9 bias2'; do
  read -r target controller <<< "$specification"
  prefix="feedforward_${target/./p}_${controller}"
  if [[ -d "results/${prefix}_01" ]]; then
    echo "Preserving existing trial $prefix"
    continue
  fi
  export LAB4_PLANNER_PROFILE="$PWD/optimization/phase2/planner_tail_${target}.yaml"
  duration=$(python3 -c 'import sys,yaml; print(sum(yaml.safe_load(open(sys.argv[1]))["segment_durations"]))' "$LAB4_PLANNER_PROFILE")
  mkdir -p "results/${prefix}_startup"
  echo "START $prefix"
  if ! python3 -u scripts/prepare_simulator.py "$PWD/results/${prefix}_startup" >"results/${prefix}_startup/dispatch.log" 2>&1 9>&-; then
    echo "STARTUP FAILED $prefix"; continue
  fi
  status=0
  bash optimization/run_trial.sh "$PWD/optimization/phase2/controller_${controller}.yaml" "$duration" "$prefix" 2.67 75 >"results/${prefix}_dispatch.log" 2>&1 9>&- || status=$?
  tail -6 "results/${prefix}_dispatch.log"
  python3 - "$prefix" "$status" <<'PY'
import json,sys
from pathlib import Path
prefix=sys.argv[1];p=Path('results')/(prefix+'_01')/'race_acceptance.json'
if p.exists():
 r=json.loads(p.read_text());print(json.dumps(dict(run=prefix,passed=r['passed'],gates=r['passed_gates'],milliseconds=r['first_gate_to_last_gate_ms'],checks=r['checks'])),flush=True)
else:print('No completed acceptance evidence: '+prefix,flush=True)
PY
  if python3 - "$prefix" <<'SUCCESS'
import json,sys
from pathlib import Path
p=Path('results')/(sys.argv[1]+'_01')/'race_acceptance.json'
r=json.loads(p.read_text()) if p.exists() else {}
raise SystemExit(0 if r.get('passed') is True and r.get('passed_gates')==12 and r.get('first_gate_to_last_gate_ms',1e9)<4000 else 1)
SUCCESS
  then
    echo "SUB4_ACCEPTED $prefix"
    break
  fi
done
python3 optimization/collect_results.py
